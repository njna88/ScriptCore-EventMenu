local ESX = exports["es_extended"]:getSharedObject()
local activeEvent = nil

-- Sikkerhedstjek: Stopper scriptet hvis mappen er omdøbt
CreateThread(function()
    local resourceName = GetCurrentResourceName()
    if resourceName ~= Config.ResourceName then
        while true do
            print(("^1[ScriptCore.dk] FEJL: Scriptet skal hedde '%s' for at køre! Nuverende navn: %s^7"):format(Config.ResourceName, resourceName))
            Wait(5000)
        end
    end
end)

-- Tjek om spilleren er admin (gruppe)
local function isAdmin()
    local playerData = ESX.GetPlayerData()
    local group = playerData.group
    
    if not group then return false end
    
    -- Kun admin gruppe har adgang
    if group == "admin" then
        return true
    end
    
    return false
end

--- Åbner hovedmenuen for Event Menu
local function openEventMenu()
    if GetCurrentResourceName() ~= Config.ResourceName then return end

    -- Tjek adgang
    if not isAdmin() then
        lib.notify({ title = "Adgang Nægtet", description = "Du har ikke adgang til denne menu", type = "error" })
        return
    end

    local options = {
        {
            title = "Event Status",
            description = activeEvent and ("Aktivt: %s (Host: %s)"):format(activeEvent.title, activeEvent.host) or "Intet aktivt event",
            onSelect = function()
                if not activeEvent then
                    local input = lib.inputDialog("Start Nyt Event", {
                        { type = "input", label = "Event Titel", placeholder = "F.eks. Race", required = true },
                        { type = "input", label = "Host Navn", placeholder = "Dit Navn", required = true },
                        { type = "textarea", label = "Beskrivelse", placeholder = "Regler osv.", required = true }
                    })

                    if input then
                        TriggerServerEvent("event_menu:server:startEvent", {
                            title = input[1],
                            host = input[2],
                            description = input[3]
                        })
                    end
                else
                    local alert = lib.alertDialog({
                        header = "Stop Event",
                        content = "Er du sikker på, at du vil afslutte det nuværende event?",
                        centered = true,
                        cancel = true
                    })
                    if alert == "confirm" then
                        TriggerServerEvent("event_menu:server:endEvent")
                    end
                end
            end
        },
        {
            title = "Køretøjer",
            description = "Spawn biler til eventet",
            onSelect = function()
                local vehOptions = {}
                for _, v in ipairs(Config.Vehicles) do
                    table.insert(vehOptions, {
                        title = v.label,
                        description = "Model: " .. v.model,
                        onSelect = function()
                            TriggerServerEvent("event_menu:server:spawnVehicle", v.model)
                        end
                    })
                end
                lib.registerContext({
                    id = "event_veh_menu",
                    title = "Vælg Køretøj",
                    menu = "event_main_menu",
                    options = vehOptions
                })
                lib.showContext("event_veh_menu")
            end
        },
        {
            title = "Items & Våben",
            description = "Giv udstyr til deltagere",
            onSelect = function()
                lib.registerContext({
                    id = "event_items_menu",
                    title = "Udstyr",
                    menu = "event_main_menu",
                    options = {
                        {
                            title = "Giv Item",
                            onSelect = function()
                                local itemOptions = {}
                                for _, i in ipairs(Config.Items) do
                                    table.insert(itemOptions, { value = i.name, label = i.label })
                                end

                                local input = lib.inputDialog("Giv Item", {
                                    { type = "select", label = "Vælg Item", options = itemOptions, required = true },
                                    { type = "number", label = "Antal", default = 1, min = 1 },
                                    { type = "number", label = "Modtager ID (Tom = Dig selv)", placeholder = "ID" }
                                })
                                if input then
                                    TriggerServerEvent("event_menu:server:giveItem", input[1], input[2], input[3])
                                end
                            end
                        },
                        {
                            title = "Giv Våben",
                            onSelect = function()
                                local weaponOptions = {}
                                for _, w in ipairs(Config.Weapons) do
                                    table.insert(weaponOptions, { value = w.model, label = w.label })
                                end

                                local input = lib.inputDialog("Giv Våben", {
                                    { type = "select", label = "Vælg Våben", options = weaponOptions, required = true },
                                    { type = "number", label = "Modtager ID (Tom = Dig selv)", placeholder = "ID" }
                                })
                                if input then
                                    TriggerServerEvent("event_menu:server:giveWeapon", input[1], input[2])
                                end
                            end
                        }
                    }
                })
                lib.showContext("event_items_menu")
            end
        },
        {
            title = "Præmier & Leaderboard",
            description = "Udbetal penge og styr wins",
            onSelect = function()
                lib.registerContext({
                    id = "event_rewards_menu",
                    title = "Præmier",
                    menu = "event_main_menu",
                    options = {
                        {
                            title = "Udbetal Penge",
                            onSelect = function()
                                local input = lib.inputDialog("Udbetal", {
                                    { type = "number", label = "Spiller ID", required = true },
                                    { type = "select", label = "Type", options = { {value = "money", label = "Kontanter"}, {value = "bank", label = "Bank"} }, required = true },
                                    { type = "number", label = "Beløb", required = true, min = 1 }
                                })
                                if input then
                                    TriggerServerEvent("event_menu:server:giveReward", input[1], input[2], input[3])
                                end
                            end
                        },
                        {
                            title = "Tilføj Win",
                            onSelect = function()
                                local input = lib.inputDialog("Registrer Vinder", {
                                    { type = "number", label = "Spiller ID", required = true },
                                    { type = "number", label = "Placering (1-3)", default = 1, min = 1, max = 3 }
                                })
                                if input then
                                    TriggerServerEvent("event_menu:server:addWin", input[1], input[2])
                                end
                            end
                        }
                    }
                })
                lib.showContext("event_rewards_menu")
            end
        }
    }

    lib.registerContext({
        id = "event_main_menu",
        title = "Event Menu - ScriptCore.dk",
        options = options
    })

    lib.showContext("event_main_menu")
end

-- Kommando til at åbne menuen
RegisterCommand("EventMenu", function()
    openEventMenu()
end, false)

-- Keybind F6
lib.addKeybind({
    name = "event_menu",
    description = "Åben Event Menu",
    defaultKey = "F6",
    onPressed = function()
        openEventMenu()
    end
})

-- Sync Events
RegisterNetEvent("event_menu:client:eventStarted", function(data)
    activeEvent = data
    lib.notify({ title = "Event Startet", description = data.title, type = "inform" })
end)

RegisterNetEvent("event_menu:client:eventEnded", function()
    activeEvent = nil
    lib.notify({ title = "Event Slut", description = "Eventet er blevet afsluttet", type = "warning" })
end)

RegisterNetEvent("event_menu:client:spawnVehicle", function(modelName)
    local hash = joaat(modelName)
    if not IsModelInCdimage(hash) then return end
    
    lib.requestModel(hash)
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local veh = CreateVehicle(hash, coords.x, coords.y, coords.z, GetEntityHeading(ped), true, false)
    TaskWarpPedIntoVehicle(ped, veh, -1)
    SetModelAsNoLongerNeeded(hash)
end)