Config = {}

-- Navne-tjek (Scriptet stopper hvis mappen ikke hedder dette)
Config.ResourceName = "ScriptCore-EventMenu"

-- Discord Logging
Config.Webhook = "DIN_DISCORD_WEBHOOK_HER" -- Indsæt din webhook URL her

-- Admin jobs der har adgang til menuen
Config.AdminJobs = {
    "admin"
}

-- Minimum grade for adgang (standard: 0)
Config.MinGrade = 0

Config.Vehicles = {
    { label = "Adder", model = "adder" },
    { label = "Zentorno", model = "zentorno" },
    { label = "T20", model = "t20" },
    { label = "Panto", model = "panto" },
    { label = "Kuruma", model = "kuruma" },
    { label = "Sultan", model = "sultan" }
}

Config.Items = {
    { label = "Brød", name = "bread" },
    { label = "Vand", name = "water" },
    { label = "Bandage", name = "bandage" },
    { label = "Medikit", name = "medikit" }
}

Config.Weapons = {
    { label = "Pistol", model = "weapon_pistol" },
    { label = "Combat Pistol", model = "weapon_combat_pistol" },
    { label = "Carbine Rifle", model = "weapon_carbinerifle" },
    { label = "Pump Shotgun", model = "weapon_pumpshotgun" }
}