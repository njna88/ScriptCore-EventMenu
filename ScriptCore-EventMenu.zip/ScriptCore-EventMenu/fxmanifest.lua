fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'ScriptCore.dk'
description 'Event Menu | ScriptCore.dk'
version '1.0.0'

dependency 'ox_lib'
shared_script '@ox_lib/init.lua'

client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'config.lua',
    'server/util.lua',
    'server.lua'
}

escrow_ignore{
    "config.lua",
}
