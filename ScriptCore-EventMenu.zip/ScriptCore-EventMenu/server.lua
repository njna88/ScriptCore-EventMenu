local ESX = exports["es_extended"]:getSharedObject()
local activeEvent = nil

-- Sikkerhedstjek: Stopper server-logik hvis mappen er omdøbt
MySQL.ready(function()
    local resourceName = GetCurrentResourceName()
    if resourceName ~= Config.ResourceName then
        print("^1[ScriptCore.dk] KRITISK FEJL: Scriptet er omdøbt! Deaktiverer funktioner.^7")
    end
end)

-- Hjælpefunktion til at tjekke om spiller er admin (gruppe)
local function hasAdminAccess(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return false end
    
    local group = xPlayer.group
    
    -- Kun admin gruppe har adgang
    if group == "admin" then
        return true
    end
    
    return false
end

-- Hjælpefunktion til at få spiller info til logs
local function getPlayerLogInfo(src)
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return "Ukendt (ID: " .. src .. ")" end
    return ("%s (ID: %s | License: %s)"):format(xPlayer.getName(), src, xPlayer.getIdentifier())
end

RegisterNetEvent("event_menu:server:startEvent", function(data)
    if GetCurrentResourceName() ~= Config.ResourceName then return end
    local src = source
    
    if not hasAdminAccess(src) then
        TriggerClientEvent("ox_lib:notify", src, { title = "Adgang Nægtet", description = "Du har ikke admin adgang", type = "error" })
        return
    end
    
    activeEvent = data
    TriggerClientEvent("event_menu:client:eventStarted", -1, data)
    
    CreateLog("Event Startet", 
        ("Admin: %s | Titel: %s | Host: %s | Beskrivelse: %s"):format(getPlayerLogInfo(src), data.title, data.host, data.description), 
        56108
    )
end)

RegisterNetEvent("event_menu:server:endEvent", function()
    if GetCurrentResourceName() ~= Config.ResourceName then return end
    local src = source
    
    if not hasAdminAccess(src) then
        TriggerClientEvent("ox_lib:notify", src, { title = "Adgang Nægtet", description = "Du har ikke admin adgang", type = "error" })
        return
    end
    
    if not activeEvent then return end
    
    CreateLog("Event Afsluttet", 
        ("Admin: %s | Event: %s"):format(getPlayerLogInfo(src), activeEvent.title), 
        15158332
    )
    
    activeEvent = nil
    TriggerClientEvent("event_menu:client:eventEnded", -1)
end)

RegisterNetEvent("event_menu:server:spawnVehicle", function(model)
    if GetCurrentResourceName() ~= Config.ResourceName then return end
    local src = source
    
    if not hasAdminAccess(src) then
        TriggerClientEvent("ox_lib:notify", src, { title = "Adgang Nægtet", description = "Du har ikke admin adgang", type = "error" })
        return
    end
    
    TriggerClientEvent("event_menu:client:spawnVehicle", src, model)
    
    CreateLog("Koeretoej Spawnet", 
        ("Admin: %s | Model: %s"):format(getPlayerLogInfo(src), model), 
        1752220
    )
end)

RegisterNetEvent("event_menu:server:giveItem", function(itemName, amount, targetId)
    if GetCurrentResourceName() ~= Config.ResourceName then return end
    local src = source
    
    if not hasAdminAccess(src) then
        TriggerClientEvent("ox_lib:notify", src, { title = "Adgang Nægtet", description = "Du har ikke admin adgang", type = "error" })
        return
    end
    
    local target = (targetId and targetId ~= 0) and targetId or src
    local xPlayer = ESX.GetPlayerFromId(target)
    
    if xPlayer then
        xPlayer.addInventoryItem(itemName, amount)
        TriggerClientEvent("ox_lib:notify", src, { title = "Succes", description = ("Gav %sx %s"):format(amount, itemName), type = "success" })
        
        CreateLog("Item Uddelt", 
            ("Fra Admin: %s | Til: %s | Item: %s | Antal: %d"):format(getPlayerLogInfo(src), getPlayerLogInfo(target), itemName, amount), 
            15844367
        )
    end
end)

RegisterNetEvent("event_menu:server:giveWeapon", function(weaponName, targetId)
    if GetCurrentResourceName() ~= Config.ResourceName then return end
    local src = source
    
    if not hasAdminAccess(src) then
        TriggerClientEvent("ox_lib:notify", src, { title = "Adgang Nægtet", description = "Du har ikke admin adgang", type = "error" })
        return
    end
    
    local target = (targetId and targetId ~= 0) and targetId or src
    local xPlayer = ESX.GetPlayerFromId(target)
    
    if xPlayer then
        xPlayer.addWeapon(weaponName, 250)
        TriggerClientEvent("ox_lib:notify", src, { title = "Succes", description = "Våben givet til ID: " .. target, type = "success" })
        
        CreateLog("Våben Uddelt", 
            ("Fra Admin: %s | Til: %s | Våben: %s"):format(getPlayerLogInfo(src), getPlayerLogInfo(target), weaponName), 
            10181046
        )
    end
end)

RegisterNetEvent("event_menu:server:giveReward", function(targetId, rewardType, amount)
    if GetCurrentResourceName() ~= Config.ResourceName then return end
    local src = source
    
    if not hasAdminAccess(src) then
        TriggerClientEvent("ox_lib:notify", src, { title = "Adgang Nægtet", description = "Du har ikke admin adgang", type = "error" })
        return
    end
    
    local xPlayer = ESX.GetPlayerFromId(tonumber(targetId))
    
    if xPlayer then
        if rewardType == "money" then 
            xPlayer.addMoney(amount)
        else 
            xPlayer.addAccountMoney(rewardType, amount) 
        end
        
        TriggerClientEvent("ox_lib:notify", src, { title = "Udbetalt", description = amount .. " kr udbetalt til ID: " .. targetId, type = "success" })
        
        CreateLog("Praemie Udbetalt", 
            ("Fra Admin: %s | Til: %s | Beloeb: %d kr | Type: %s"):format(getPlayerLogInfo(src), getPlayerLogInfo(targetId), amount, rewardType), 
            3066993
        )
    end
end)

RegisterNetEvent("event_menu:server:addWin", function(targetId, placement)
    if GetCurrentResourceName() ~= Config.ResourceName then return end
    local src = source
    
    if not hasAdminAccess(src) then
        TriggerClientEvent("ox_lib:notify", src, { title = "Adgang Nægtet", description = "Du har ikke admin adgang", type = "error" })
        return
    end
    
    local xPlayer = ESX.GetPlayerFromId(tonumber(targetId))
    if not xPlayer then return end
    
    local name = xPlayer.getName()
    TriggerClientEvent("ox_lib:notify", -1, { 
        title = "Event Vinder!", 
        description = ("%s fik en %s. plads!"):format(name, placement), 
        type = "inform",
        position = "top"
    })

    CreateLog("Vinder Registreret", 
        ("Admin: %s | Vinder: %s | Placering: %s. plads"):format(getPlayerLogInfo(src), getPlayerLogInfo(targetId), placement), 
        15105570
    )
end)