local function sendToDiscord(title, message, color)
    if Config.Webhook == "DIN_DISCORD_WEBHOOK_HER" or Config.Webhook == "" then 
        return print("^1[ScriptCore.dk] Fejl: Discord Webhook er ikke sat op i config.lua^7") 
    end

    local embed = {
        {
            ["title"] = title,
            ["description"] = message,
            ["color"] = color or 3447003,
            ["footer"] = {
                ["text"] = os.date("%Y-%m-%d %H:%M:%S"),
            },
            ["author"] = {
                ["name"] = "ScriptCore.dk Event Logs",
            },
        }
    }

    PerformHttpRequest(Config.Webhook, function(err, text, headers) end, "POST", json.encode({username = "ScriptCore.dk Logger", embeds = embed}), { ["Content-Type"] = "application/json" })
end

--- Global log funktion
function CreateLog(title, message, color)
    sendToDiscord(title, message, color)
end